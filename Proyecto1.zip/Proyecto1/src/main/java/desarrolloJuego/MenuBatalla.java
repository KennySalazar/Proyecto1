
package desarrolloJuego;

/**
 *
 * @author Kenny
 */
import java.util.concurrent.ThreadLocalRandom;
import mascotas.DatosJugador;
import mascotas.Comida;
import mascotas.Tipos;
import java.util.Scanner;

public class MenuBatalla
{
    Scanner entrada = new Scanner(System.in);
    CamposDeJuego campos = new CamposDeJuego();;
    Tipos nivel = new Tipos("", "", 0.0, 0.0, 0, 0, "", 0, 0);;
    Comida com = new Comida("", "", 0, true, "");
    
    public static DatosJugador datos = new DatosJugador();
    private Tipos[] mascota= new Tipos[5];
    private int opcion;
    private int contadorMisMascotas = 0;
    private Tipos[] miMascota = new Tipos[5];
    private Tipos[] miMascotaNivel2 = new Tipos[5];
    private Tipos[] miMascotaNivel3 = new Tipos[5];
    private Tipos[] mascotaRival = new Tipos[5];
    
    
    public Tipos[] getMiMascota() {
        return miMascota;
    }
    
    public Tipos[] getMascota() {
        return mascota;
    }
    
    public void setMascota( Tipos[] mascota) {
        this.mascota = mascota;
    }
    
    public void mostrarMenuBatallas() {
        
        nivel.inicializarAnimales();
        mostrarAnimalesEnTienda(nivel.getArregloMascota(), datos.getContRonda());
        do {
            System.out.println("----------------------------------------");
            System.out.println( "\n**CANTIDAD DE ORO**\n"+ datos.getOro());
            System.out.println("----------------------------------------");
            System.out.println("**VIDAS**\n"+ datos.getVida());
            System.out.println("----------------------------------------");
            System.out.println("**VICTORIAS**\n" + datos.getContVictorias());
            System.out.println("----------------------------------------");
            System.out.println("**VAMOS EN LA RONDA**\n" + datos.getContRonda());
            System.out.println("----------------------------------------");
            
            System.out.println("\nEliga una de las siguientes opciones");
            System.out.println("\t1. COMPRAR MASCOTAS");
            System.out.println("\t2. COMPRAR COMIDA");
            System.out.println("\t3. ORDENAR MASCOTAS");
            System.out.println("\t4. FUSIONAR MASCOTAS");
            System.out.println("\t5. VENDER MASCOTAS");
            System.out.println("\t6. INICIAR JUEGO");
            System.out.println("\t0. SALIR");
            
            switch (opcion = entrada.nextInt()) {
                case 1: {
                    while (opcion != 2) {
                        System.out.println("\n-------------------------MASCOTAS EN TIENDA---------------------");
                        imprimirMascotasEnTienda(datos.getContRonda()); //falta arreglar
                        System.out.println("\t1. Comprar");
                        System.out.println("\t2. regresar");
                        System.out.println("\t3. Ver Mascotas Compradas");
                        opcion = entrada.nextInt();
                        
                        if (opcion == 1) {
                            System.out.println("Para comprar una mascota ingrese: Nombre de  la Mascota que desea comprar");
                            System.out.println("Ejemplo: PESCADO, pescado");
                             String comando = entrada.next();
                            boolean comprado = false;
                            for (int i = 0; i < 5; ++i) {
                                if (mascota[i] != null && comando.equalsIgnoreCase(mascota[i].getNombre())) {
                                    if (MenuBatalla.datos.getOro() >= 3) {
                                        guardarMascotaComprada(mascota, miMascota, i);
                                        comprado = true;
                                        datos.setOro(MenuBatalla.datos.getOro() - 3);
                                    }
                                    else {
                                        System.out.println("**No tienes suficiente oro para comprar mascotas**\n");
                                        comprado = true;
                                    }
                                    i = 5;
                                    break;
                                }
                            }
                            if (!comprado) {
                                System.out.println("**\tComando incorrecto**");
                            }
                        }
                        if (opcion == 3) {
                            System.out.println("---------MASCOTAS COMPRADAS----------:");
                            imprimirMascotasCompradas(miMascota);
                        }
                    }
                    break;
                }
                case 2: {
                    com.comprarComidaEnTienda(com.getAlimentos(), MenuBatalla.datos.getContRonda(), miMascota);
                    break;
                }
                case 3: {
                    ordenarMazoBatalla(miMascota);
                    break;
                }
                case 4: {
                    fusionarMascotas(mascota, miMascota);
                    break;
                }
                case 5: {
                    venderMascotas(miMascota);
                    break;
                }
                case 6: {
                    System.out.println("----MASCOTAS RIVAL----");
                    mostrarMascotasRival(nivel.getArregloMascota(), datos.getContRonda());
                    campos.mostrarCamposDeJuego(miMascota, mascotaRival, datos.getContRonda());
                    break;
                }
                case 0: {
                    break;
                }
                default: {
                    System.out.println("La opcion que elegiste no existe, vuelve a intentarlo");
                    break;
                }
            }
        } while (opcion != 0);
    }
    
    public void mostrarAnimalesEnTienda( Tipos[] mascotas,  int Ronda) {
        int numAnimales = 0;
        if (Ronda <= 3) {
            numAnimales = 3;
        }
        else if (Ronda >= 4 && Ronda <= 6) {
            numAnimales = 4;
        }
        else if (Ronda >= 7) {
            numAnimales = 5;
        }
        for (int i = 0; i < numAnimales; ++i) {
            boolean encontro = false;
            while (!encontro) {
                final ThreadLocalRandom tlr = ThreadLocalRandom.current();
                final int mascotaAleatoria = tlr.nextInt(0, 53);
                if (Ronda == 1 || Ronda == 2) {
                    if (mascotas[mascotaAleatoria].getNivelJuego() == 1) {
                        encontro = true;
                    this.mascota[i] = mascotas[mascotaAleatoria];
                    }
                    
                }
                else if (Ronda == 3 || Ronda == 4) {
                    if (mascotas[mascotaAleatoria].getNivelJuego() <= 2) {
                      encontro = true;
                    this.mascota[i] = mascotas[mascotaAleatoria];
                    }
                    
                }
                else if (Ronda == 5 || Ronda == 6) {
                    if (mascotas[mascotaAleatoria].getNivelJuego() <= 3) {
                       encontro = true;
                    this.mascota[i] = mascotas[mascotaAleatoria];
                    }
                    
                }
                else if (Ronda == 7 || Ronda == 8) {
                    if (mascotas[mascotaAleatoria].getNivelJuego() <= 4) {
                      encontro = true;
                    this.mascota[i] = mascotas[mascotaAleatoria];
                    }
                    
                }
                else if (Ronda == 9 || Ronda == 10) {
                    if (mascotas[mascotaAleatoria].getNivelJuego() <= 5) {
                        encontro = true;
                    this.mascota[i] = mascotas[mascotaAleatoria];
                    }
                   
                }
                else if (Ronda == 11 || Ronda == 12) {
                    if (mascotas[mascotaAleatoria].getNivelJuego() <= 6) {
                        encontro = true;
                    this.mascota[i] = mascotas[mascotaAleatoria];
                    }
                    
                }
                else if (Ronda == 13 || Ronda == 14) {
                    if (mascotas[mascotaAleatoria].getNivelJuego() <= 7) {
                        encontro = true;
                    this.mascota[i] = mascotas[mascotaAleatoria];
                    }
                    
                }
                else {
                    if (Ronda <= 14 || mascotas[mascotaAleatoria].getNivelJuego() > 7) {
                      encontro = true;
                    this.mascota[i] = mascotas[mascotaAleatoria];
                    }
                    
                }
            }
        }
    }
    
    public void guardarMascotaComprada( Tipos[] mascotaComprada,  Tipos[] miMascota,  int posicion) {
        try {
            System.out.println("\t**Mascota comprado con exito**");
            miMascota[contadorMisMascotas] = mascotaComprada[posicion];
            ++contadorMisMascotas;
            mascotaComprada[posicion] = null;
        }
        catch (Exception e) {
            System.out.println("No puedes llevar mas de 5 mascotas");
        }
    }
    
    public void imprimirMascotasCompradas( Tipos[] mascota) { //falta componer
        for (int i = 0; i < mascota.length; ++i) {
            if (mascota[i] != null) {
                nivel.mostrarDatos(mascota[i]);
            }
        }
    }
    
    public void imprimirMascotasEnTienda( int ronda) {
        for (int i = 0; i < mascota.length; ++i) {
            if (ronda <= 2) {
                nivel.mostrarDatos(mascota[i]);
            }
        }
    }
    
    public void ordenarMazoBatalla( Tipos[] mazo) {
        System.out.println("----------------------------");
        imprimirMascotasCompradas(miMascota);
         Tipos[] arregloMazo = new Tipos[5];
        int contMazo = 0;
        boolean ordeno = false;
        for (int i = 0; i < mazo.length; ++i) {
            if (mazo[i] != null) {
                ++contMazo;
            }
        }
        for (int i = 0; i < contMazo; ++i) {
            while (!ordeno) {
                System.out.println("\nIngrese el nombre de la mascota que desea poner en esa posicion");
                System.out.println("Que mascota desea que vaya en la posición: " +  (i+01));
                 String nombre = entrada.next();
                for (int j = 0; j < mazo.length; ++j) {
                    if (mazo[j] != null && nombre.equalsIgnoreCase(mazo[j].getNombre())) {
                        arregloMazo[i] = mazo[j];
                        ordeno = true;
                        break;
                    }
                }
                if (!ordeno) {
                    System.out.println("**Comando Incorrecto**");
                }
            }
            ordeno = false;
        }
        System.out.println("\n-----Mazo para la batalla----");
        for (int i = 0; i < arregloMazo.length; ++i) {
            if (arregloMazo[i] != null) {
                nivel.mostrarDatos(arregloMazo[i]);
            }
        }
        for (int i = 0; i < arregloMazo.length; ++i) {
            mazo[i] = arregloMazo[i];
        }
    }
    
    public void venderMascotas( Tipos[] mazo5) {
        for (int opcionSeleccionada = 0; opcionSeleccionada != 2; opcionSeleccionada = entrada.nextInt()) {
            for (int i = 0; i < mazo5.length; ++i) {
                this.nivel.mostrarDatos(mazo5[i]);
            }
            System.out.println("Ingrese el nombre de la mascota que desea vender");
             String comando = entrada.next();
            for (int j = 0; j < mazo5.length; ++j) {
                if (mazo5[j] != null && comando.equalsIgnoreCase(mazo5[j].getNombre())) {
                    datos.setOro(datos.getOro() + mazo5[j].getNivel());
                    mazo5[j] = null;
                    System.out.println("**Mascota vendida con exito**\n");
                    --contadorMisMascotas;
                    ordenarAuto(miMascota);
                    break;
                } else{
                    System.out.println("Comando Incorrecto");
                }
            }
            System.out.println("\t1. Seguir vendiendo");
            System.out.println("\t2. Regresar");
        }
    }
    
    public void ordenarAuto( Tipos[] miMascota) {
        int contNuevo = 0;
         Tipos[] tiposConfiNueva = new Tipos[5];
        for (int i = 0; i < miMascota.length; ++i) {
            if (miMascota[i] != null) {
                tiposConfiNueva[contNuevo] = miMascota[i];
                ++contNuevo;
            }
        }
        for (int j = 0; j < miMascota.length; ++j) {
            miMascota[j] = tiposConfiNueva[j];
        }
    }
    
    public void fusionarMascotas( Tipos[] mascotaTienda,  Tipos[] miMascota) {
        int opcionSeleccion = 0;
        boolean hayMascotas = false;
        boolean hayMascotasTienda = false;
        while (opcionSeleccion != 3) {
            System.out.println("\t1. Fusionar");
            System.out.println("\t2. Ver Mascota Fusionada");
            System.out.println("\t3. Regresar");
            opcionSeleccion = entrada.nextInt();
            if (opcionSeleccion == 1) {
                System.out.println("----Mascotas para fusionar---");
                for (int i = 0; i < mascotaTienda.length; ++i) {
                    nivel.mostrarDatos(mascotaTienda[i]);
                }
                System.out.println("---Mis Mascotas---");
                for (int j = 0; j < miMascota.length; ++j) {
                    nivel.mostrarDatos(miMascota[j]);
                }
                System.out.println("\nIngrese el nombre de la mascota que desea fusionar");
                 String comando = entrada.next();
                int k = 0;
                while (k < mascotaTienda.length) {
                    if (mascotaTienda[k] != null && comando.equalsIgnoreCase(mascotaTienda[k].getNombre())) {
                        hayMascotasTienda = true;
                        System.out.println("Buscando mascota.....\n");
                        for (int l = 0; l < miMascota.length; ++l) {
                            if (miMascota[l] != null && comando.equalsIgnoreCase(miMascota[l].getNombre())) {
                                miMascota[l].setPuntosAtaque(miMascota[l].getPuntosAtaque() + 1);
                                miMascota[l].setPuntosVida(miMascota[l].getPuntosVida() + 1);
                                miMascota[l].setFusion(miMascota[l].getFusion() + 1);
                                mascotaTienda[k] = null;
                                hayMascotas = true;
                                MenuBatalla.datos.setOro(MenuBatalla.datos.getOro() - 3);
                                if (miMascota[l].getFusion() == 2 && miMascota[l].getNivel() == 1) {
                                    miMascota[l].setNivel(2);
                                    miMascota[l].setFusion(0);
                                    System.out.println(miMascota[l].getNombre() + "Ha subido al nivel " + miMascota[l].getNivel());
                                }
                                else if (miMascota[l].getFusion() == 3 && miMascota[l].getNivel() == 2) {
                                    miMascota[l].setNivel(3);
                                    miMascota[l].setFusion(0);
                                    System.out.println(miMascota[l].getNombre() + "Ha subido al nivel " + miMascota[l].getNivel());
                                }
                                System.out.println("\nECHO!!\n");
                                break;
                            }
                        }
                        if (hayMascotas == false) {
                            System.out.println("No hay mascotas repetidas para fusionar");
                        }
                        
                        break;
                    }
                    else {
                        ++k;
                    }
                }
                if (hayMascotasTienda == false) {
                 System.out.println("**No tienes mascotas en la tienda para fusionar**");
                }
                
            }
            else {
                if (opcionSeleccion != 2) {
                    continue;
                }
                for (int i = 0; i < miMascota.length; ++i) {
                    nivel.mostrarDatos(miMascota[i]);
                }
            }
        }
    }
    
    public void mostrarMascotasRival(Tipos[] mascotaRival, int Ronda) {
        int numAnimales = 0;
        if (Ronda == 1) {
            numAnimales = 3;
        }
        else if (Ronda == 2) {
            numAnimales = 4;
        }
        else if (Ronda >= 3) {
            numAnimales = 5;
        }
        for (int i = 0; i < numAnimales; ++i) {
            boolean encontro = false;
            while (!encontro) {
                final ThreadLocalRandom tlr = ThreadLocalRandom.current();
                final int mascotaAleatoria = tlr.nextInt(0, 53);
                if (Ronda == 1 || Ronda == 2) {
                    if (mascotaRival[mascotaAleatoria].getNivelJuego() == 1) {
                       encontro = true;
                    this.mascotaRival[i] = mascotaRival[mascotaAleatoria];
                    }
                    
                }
                else if (Ronda == 3 || Ronda == 4) {
                    if (mascotaRival[mascotaAleatoria].getNivelJuego() <= 2) {
                        encontro = true;
                    this.mascotaRival[i] = mascotaRival[mascotaAleatoria];
                    }
                    
                }
                else if (Ronda == 5 || Ronda == 6) {
                    if (mascotaRival[mascotaAleatoria].getNivelJuego() <= 3) {
                       encontro = true;
                    this.mascotaRival[i] = mascotaRival[mascotaAleatoria];
                    }
                    
                }
                else if (Ronda == 7 || Ronda == 8) {
                    if (mascotaRival[mascotaAleatoria].getNivelJuego() <=  4) {
                        encontro = true;
                    this.mascotaRival[i] = mascotaRival[mascotaAleatoria];
                    }
                    
                }
                else if (Ronda == 9 || Ronda == 10) {
                    if (mascotaRival[mascotaAleatoria].getNivelJuego() <= 5) {
                       encontro = true;
                    this.mascotaRival[i] = mascotaRival[mascotaAleatoria];
                    }
                    
                }
                else if (Ronda == 11 || Ronda == 12) {
                    if (mascotaRival[mascotaAleatoria].getNivelJuego() <= 6) {
                       encontro = true;
                    this.mascotaRival[i] = mascotaRival[mascotaAleatoria];
                    }
                    
                }
                else if (Ronda == 13 || Ronda == 14) {
                    if (mascotaRival[mascotaAleatoria].getNivelJuego() <= 7) {
                      encontro = true;
                    this.mascotaRival[i] = mascotaRival[mascotaAleatoria];
                    }
                    
                }
                else {
                    if (Ronda <= 14 || mascotaRival[mascotaAleatoria].getNivelJuego() > 7) {
                          encontro = true;
                    this.mascotaRival[i] = mascotaRival[mascotaAleatoria];
                    }
                  
                }
            }
        }
        for (int i = 0; i < this.mascotaRival.length; ++i) {
            if (this.mascotaRival[i] != null) {
                nivel.mostrarDatos(this.mascotaRival[i]);
            }
        }
    }
      
}