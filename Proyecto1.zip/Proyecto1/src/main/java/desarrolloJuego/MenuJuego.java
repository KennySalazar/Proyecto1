package desarrolloJuego;

/**
 *
 * @author Kenny
 */
import java.util.Scanner;

public class MenuJuego {

    Scanner entrada = new Scanner(System.in);
    private int opcion = 0;
    MenuBatalla menu = new MenuBatalla();

    public void mostrarMenu() {
        do {
            System.out.println("*****BIENVENIDO******");
            System.out.println("Seleccione a que opcion desea ir");
            System.out.println("\t1. MODO ARENA");
            System.out.println("\t2. MODO VERSUS");
            System.out.println("\t3. MODO CREATIVO");
            System.out.println("\t4. SALIR");

            switch (opcion = entrada.nextInt()) {
                case 1: {
                    menu.mostrarMenuBatallas();
                    break;
                }
                case 2: {
                    break;
                }
                case 3: {
                    break;
                }
                case 4: {
                    System.out.println("Saliendo del juego.....");
                    break;
                }
                default: {
                    System.out.println("La opcion que elegiste no existe, vuelve a intentarlo");
                    break;
                }
            }
        } while (opcion != 4);
    }
}
