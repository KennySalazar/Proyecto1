/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package desarrolloJuego;

/**
 *
 * @author Kenny
 */
import java.util.Scanner;
import jugar.Batalla;
import mascotas.BufYNerfeo;
import mascotas.Tipos;

public class CamposDeJuego {

    Scanner entrada = new Scanner(System.in);

    Tipos nivel = new Tipos("", "", 0, 0, 0, 0, "", 0, 0);
    BufYNerfeo buf = new BufYNerfeo("", "", 0, 0, 0, 0, "", 0, 0);
    Batalla bat = new Batalla();
    private int opcionC;

    public void mostrarCamposDeJuego(Tipos miMascota[], Tipos mascotaRival[], int ronda) {
        while (opcionC != -1) {

            System.out.println("\nEliga un campo de juego para iniciar la batalla");
            System.out.println("\t1. CAMPO POR DEFECTO");
            System.out.println("\t2. PANTANO");
            System.out.println("\t3. NUBES");
            System.out.println("\t4. MAR");
            System.out.println("\t5. BOSQUE");
            System.out.println("\t6. GRANJA");
            System.out.println("\t7. SABANA");
            System.out.println("\t-1. REGRESAR AL MENU ANTERIOR");
            opcionC = entrada.nextInt();

            System.out.println("¡¡SE LE APLICO EL BUF O NERFEO CORRESPONDIENTE A CADA MASCOTA!!");
            
            switch (opcionC) {
                case 1:
                    System.out.println("--------------------");
                    System.out.println("----MIS MASCOTAS----");
                    buf.bufearMascotaSolitaria(miMascota);

                    System.out.println("---------------------\n");
                    System.out.println("----MASCOTA RIVAL----");
                    buf.bufearMascotaSolitaria(mascotaRival);
                    System.out.println("---------------------");

                    bat.iniciarPelea(miMascota, mascotaRival, ronda);

                    break;

                case 2:
                    System.out.println("--------------------");
                    System.out.println("----MIS MASCOTAS----");
                        buf.bufearMascotaReptil(miMascota);
                      
                    System.out.println("---------------------\n");
                    System.out.println("----MASCOTA RIVAL----");
                        buf.bufearMascotaReptil(mascotaRival);
                    System.out.println("---------------------");
                    
                    bat.iniciarPelea(miMascota, mascotaRival, ronda);

                    break;

                case 3:
                    System.out.println("--------------------");
                    System.out.println("----MIS MASCOTAS----");
                        buf.bufearMascotaVolador(miMascota);
                        
                    System.out.println("---------------------\n");
                    System.out.println("----MASCOTA RIVAL----");
                        buf.bufearMascotaVolador(mascotaRival);
                    System.out.println("---------------------");
                       
                    bat.iniciarPelea(miMascota, mascotaRival, ronda);

                    break;

                case 4:
                    System.out.println("--------------------");
                    System.out.println("----MIS MASCOTAS----");
                    buf.bufearMascotaAcuatica(miMascota);

                    System.out.println("---------------------\n");
                    System.out.println("----MASCOTA RIVAL----");
                    buf.bufearMascotaAcuatica(mascotaRival);
                    System.out.println("---------------------");
                    bat.iniciarPelea(miMascota, mascotaRival, ronda);

                    break;

                case 5:
                    System.out.println("--------------------");
                    System.out.println("----MIS MASCOTAS----");
                        buf.bufearMascotaTerrestreMamiferoSolitario(miMascota);
                      
                    System.out.println("---------------------\n");
                    System.out.println("----MASCOTA RIVAL----");
                        buf.bufearMascotaTerrestreMamiferoSolitario(mascotaRival);
                    System.out.println("---------------------");
                       
                    bat.iniciarPelea(miMascota, mascotaRival, ronda);

                    break;

                case 6:
                    System.out.println("--------------------");
                    System.out.println("----MIS MASCOTAS----");
                        buf.bufearMascotaDomesticoMamifero(miMascota);
                       
                    System.out.println("---------------------\n");
                    System.out.println("----MASCOTA RIVAL----");
                        buf.bufearMascotaDomesticoMamifero(mascotaRival);
                    System.out.println("---------------------"); 
                    bat.iniciarPelea(miMascota, mascotaRival, ronda);

                    break;

                case 7:
                    System.out.println("--------------------");
                    System.out.println("----MIS MASCOTAS----");
                        buf.bufearMascotaDisertica(miMascota);
                       
                    System.out.println("---------------------\n");
                    System.out.println("----MASCOTA RIVAL----");
                        buf.bufearMascotaDisertica(mascotaRival);
                    System.out.println("----------------------");
                    bat.iniciarPelea(miMascota, mascotaRival, ronda);

                    break;
                case -1:

                    break;
                default:
                    System.out.println("Opcion incorrecta");
                    break;
            }
        }
    }

}
