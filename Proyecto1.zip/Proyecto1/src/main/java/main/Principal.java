package main;

/**
 *
 * @author Kenny
 */
import desarrolloJuego.MenuJuego;

public class Principal {

    public static void main(String[] args) {
        MenuJuego opciones = new MenuJuego();

        opciones.mostrarMenu();
    }
}
