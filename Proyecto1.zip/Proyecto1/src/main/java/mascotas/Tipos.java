
package mascotas;

/**
 *
 * @author Kenny
 */
public class Tipos extends Animal
{
    private String figura;
    private String tipo;
    private Tipos[] arregloMascota = new Tipos[54];
    private int efecto;
    
    public Tipos(String nombre,String figura,double puntosAtaque, double puntosVida, int nivel, int nivelJuego,String tipo, int efecto, int fusion) {
        super(nombre, puntosAtaque, puntosVida, nivel, nivelJuego, fusion);  
        this.figura = figura;
        this.tipo = tipo;
        this.efecto = efecto;
    }

    
    public String getFigura() {
        return figura;
    }
    
    public String getTipo() {
        return tipo;
    }
    
    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
    
    public Tipos[] getArregloMascota() {
        return arregloMascota;
    }
    
    public int getEfecto() {
        return efecto;
    }
    
    public void setEfecto(int efecto) {
        this.efecto = efecto;
    }
    
    public void inicializarAnimales() {
        //MASCOTAS NIVEL 1 {NOMBRE-FIGURA-ATAQUE-VIDA-NIVEL ACTUAL-NIVEL JUEGO-TIPOS-FUSION-EFECTO}
        arregloMascota[0] = new Tipos("Hormiga", "oo”", 2, 1, 1, 1, "insecto/terrestre", 0, 0);
        arregloMascota[1] = new Tipos("Pescado", ">O3", 2, 3, 1, 1, "acuatico", 0, 0);
        arregloMascota[2] = new Tipos("Mosquito", "--°I°--", 2, 2, 1, 1, "volador", 0, 0);
        arregloMascota[3] = new Tipos("Grillo", "6O:”", 1, 2, 1, 1, "insecto", 0, 0);
        arregloMascota[4] = new Tipos("Castor", "˃°..°˂", 2, 2, 1, 1, "terrestre/acuatico", 0, 0);
        arregloMascota[5] = new Tipos("Caballo", "CC°”", 2, 1, 1, 1, "mamifero/domestico", 0, 0);
        arregloMascota[6] = new Tipos("Nutria", "°o°=", 1, 2, 1, 1, "mamifero", 0, 0);
        arregloMascota[7] = new Tipos("Escarabajo", "-:qqqO”", 2, 3, 1, 1, "insecto", 0, 0);
        
        //MASCOTAS NIVEL 2 {NOMBRE-FIGURA-ATAQUE-VIDA-NIVEL ACTUAL-NIVEL JUEGO-TIPOS-FUSION-EFECTO}
        arregloMascota[8] = new Tipos("Sapo", "¬o-o¬", 3, 3, 1, 2, "terrestre/acuatico", 0, 0);
        arregloMascota[9] = new Tipos("Dodo", "|-^ð^-|", 2, 3, 1, 2, "volador", 0, 0);
        arregloMascota[10] = new Tipos("Elefante", "~)^s^(~", 3, 5, 1, 2, "mamifero/terrestre", 0, 0);
        arregloMascota[11] = new Tipos("PuercoEspin", "**(°+°)**", 3, 2, 1, 2, "solitario/terrestre", 0, 0);
        arregloMascota[12] = new Tipos("Pavoreal", "^°¿°^", 2, 5, 1, 2, "domestico/volador", 0, 0);
        arregloMascota[13] = new Tipos("Rata", "_°~r~°_", 4, 5, 1, 2, "terrestre/solitario", 0, 0);
        arregloMascota[14] = new Tipos("Zorro", "+°-o-°+", 5, 2, 1, 2, "solitario/terrestre", 0, 0);
        arregloMascota[15] = new Tipos("Ara\u00f1a", "*~X~*", 2, 2, 1, 2, "insecto", 0, 0);
        
        //MASCOTAS NIVEL 3 {NOMBRE-FIGURA-ATAQUE-VIDA-NIVEL ACTUAL-NIVEL JUEGO-TIPOS-FUSION-EFECTO}
        arregloMascota[16] = new Tipos("Camello", "9nn#’’", 2, 5, 1, 3, "mamifero/disertico", 0, 0);
        arregloMascota[17] = new Tipos("Mapache", "#°8°#", 5, 4, 1, 3, "solitario", 0, 0);
        arregloMascota[18] = new Tipos("Jirafa", "O:L’", 2, 5, 1, 3, "mamifero/terrestre", 0, 0);
        arregloMascota[19] = new Tipos("Tortuga", ".O.*", 1, 2, 1, 3, "reptil", 0, 0);
        arregloMascota[20] = new Tipos("Caracol", "@°", 2, 2, 1, 3, "insecto/solitario", 0, 0);
        arregloMascota[21] = new Tipos("Oveja", "vOv°", 2, 2, 1, 3, "domestico/terrestre", 0, 0);
        arregloMascota[22] = new Tipos("Conejo", "J=*8*=J", 3, 2, 1, 3, "mamifero", 0, 0);
        arregloMascota[23] = new Tipos("Lobo", "^°8°^u", 3, 4, 1, 3, "mamifero", 0, 0);
        arregloMascota[24] = new Tipos("Buey", "q°ñ°p", 1, 4, 1, 3, "mamifero", 0, 0);
        arregloMascota[25] = new Tipos("Canguro", "/@°", 1, 2, 1, 3, "mamifero/terrestre", 0, 0);
        arregloMascota[26] = new Tipos("Buho", "~v°V°v~", 5, 3, 1, 3, "volador/Solitario", 0, 0);
        
        //MASCOTAS NIVEL 4 {NOMBRE-FIGURA-ATAQUE-VIDA-NIVEL ACTUAL-NIVEL JUEGO-TIPOS-FUSION-EFECTO}
        arregloMascota[27] = new Tipos("Venado", "^*+*^", 1, 1, 1, 4, "mamifero", 0, 0);
        arregloMascota[28] = new Tipos("Loro", "~°v°~", 5, 3, 1, 4, "volador", 0, 0);
        arregloMascota[29] = new Tipos("Hipopotamo", "~/*u*/~", 4, 7, 1, 4, "acuatico/terrestre", 0, 0);
        arregloMascota[30] = new Tipos("Delfin", "~^u^~", 4, 6, 1, 4, "acuatico", 0, 0);
        arregloMascota[31] = new Tipos("Puma", "~°’3’°~", 3, 7, 1, 4, "mamifero/terrestre", 0, 0);
        arregloMascota[32] = new Tipos("Ballena", "=°6°=", 3, 8, 1, 4, "acuatico", 0, 0);
        arregloMascota[33] = new Tipos("Ardilla", "-*:+*-", 2, 5, 1, 4, "domestico", 0, 0);
        arregloMascota[34] = new Tipos("Llama", "-<°J°>-", 3, 6, 1, 4, "terrestre", 0, 0);
        
        //MASCOTAS NIVEL 5 {NOMBRE-FIGURA-ATAQUE-VIDA-NIVEL ACTUAL-NIVEL JUEGO-TIPOS-FUSION-EFECTO}
        arregloMascota[35] = new Tipos("Foca", "jj°3°f", 3, 8, 1, 5, "acuatico/mamifero", 0, 0);
        arregloMascota[36] = new Tipos("Jaguar", "“((°8°))”", 7, 4, 1, 5, "mamifero/terrestre", 0, 0);
        arregloMascota[37] = new Tipos("Escorpion", "°°°oOo=", 1, 1, 1, 5, "disertico/solitario", 0, 0);
        arregloMascota[38] = new Tipos("Rinoceronte", "‘[°^°]’", 5, 8, 1, 5, "disertico/terrestre", 0, 0);
        arregloMascota[39] = new Tipos("Mono", "0(°8°)0", 1, 2, 1, 5, "mamifero", 0, 0);
        arregloMascota[40] = new Tipos("Cocodrilo", "***==° ˂", 8, 4, 1, 5, "reptil/solitario", 0, 0);
        arregloMascota[41] = new Tipos("Vaca", "{*O*}", 4, 6, 1, 5, "mamifero/terrestre", 0, 0);
        arregloMascota[42] = new Tipos("Chompipe", "((¡v¡))", 3, 4, 1, 5, "terrestre/volador", 0, 0);
        
        //MASCOTAS NIVEL 6 {NOMBRE-FIGURA-ATAQUE-VIDA-NIVEL ACTUAL-NIVEL JUEGO-TIPOS-FUSION-EFECTO}
        arregloMascota[43] = new Tipos("Panda", "~(°=°)~", 5, 5, 1, 6, "mamifero/solitario", 0, 0);
        arregloMascota[44] = new Tipos("Gato", "‘’>3<’’", 4, 5, 1, 6, "mamifero/domestico", 0, 0);
        arregloMascota[45] = new Tipos("Tigre", "<~^8^~>", 4, 3, 1, 6, "mamifero/terrestre", 0, 0);
        arregloMascota[46] = new Tipos("Serpiente", "--°s°--", 6, 6, 1, 6, "reptil/terrestre/disertico", 0, 0);
        arregloMascota[47] = new Tipos("Mamut", "¬3~3¬", 3, 10, 1, 6, "mamifero/terrestre/solitario", 0, 0);
        arregloMascota[48] = new Tipos("Leopardo", "'/´e+e´/", 10, 4, 1, 6, "mamifero/terrestre", 0, 0);
        arregloMascota[49] = new Tipos("Gorila", "~°-g-°~", 6, 9, 1, 6, "mamifero/terrestre", 0, 0);
        arregloMascota[50] = new Tipos("Pulpo", "}w°+°w{", 8, 8, 1, 6, "acuatico/solitario", 0, 0);
        arregloMascota[51] = new Tipos("Mosca", "‘-^n^-’", 5, 5, 1, 6, "volador/insecto", 0, 0);
        
        //MASCOTAS NIVEL 7 {NOMBRE-FIGURA-ATAQUE-VIDA-NIVEL ACTUAL-NIVEL JUEGO-TIPOS-FUSION-EFECTO}
        arregloMascota[52] = new Tipos("Quetzal", "~^°g°^~", 10, 10, 1, 7, "volador/solitario", 0, 0);
        arregloMascota[53] = new Tipos("Camaleon", "-*<&>*-", 8, 8, 1, 7, "reptil/solitario", 0, 0);
    }
    
    public void mostrarDatos(Tipos figura) {
        if (figura != null) {
            System.out.println("\n" + figura.getNombre() + "---> " + figura.getFigura()
                    + "\nPuntos de Ataque: " + figura.getPuntosAtaque()
                    + "\nPuntos de Vida: " + figura.getPuntosVida()
                    + "\nNivel Actual: " + figura.getNivel() + "\n");
        }
    }
}

