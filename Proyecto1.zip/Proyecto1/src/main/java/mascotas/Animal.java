/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mascotas;

/**
 *
 * @author Kenny
 */
public class Animal {

    protected String nombre;
    protected double puntosAtaque;
    protected double puntosVida;
    protected int nivel;
    protected int nivelJuego;
    protected int fusion;

    public Animal(String nombre, double puntosAtaque, double puntosVida, int nivel, int nivelJuego, int fusion) {
        this.puntosAtaque = puntosAtaque;
        this.puntosVida = puntosVida;
        this.nombre = nombre;
        this.puntosAtaque = puntosAtaque;
        this.puntosVida = puntosVida;
        this.nivel = nivel;
        this.nivelJuego = nivelJuego;
        this.fusion = fusion;
    }

    public int getFusion() {
        return fusion;
    }

    public void setFusion(int fusion) {
        this.fusion = fusion;
    }

    public String getNombre() {
        return nombre;
    }

    public double getPuntosAtaque() {
        return puntosAtaque;
    }

    public void setPuntosAtaque(double puntosAtaque) {
        this.puntosAtaque = puntosAtaque;
    }

    public double getPuntosVida() {
        return puntosVida;
    }

    public void setPuntosVida(double puntosVida) {
        this.puntosVida = puntosVida;
    }

    public int getNivel() {
        return nivel;
    }

    public void setNivel(int nivel) {
        this.nivel = nivel;
    }

    public int getNivelJuego() {
        return nivelJuego;
    }
}
