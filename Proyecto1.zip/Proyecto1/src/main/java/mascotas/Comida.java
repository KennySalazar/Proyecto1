package mascotas;

/**
 *
 * @author Kenny
 */
import desarrolloJuego.MenuBatalla;
import java.util.Scanner;
import java.util.concurrent.ThreadLocalRandom;

public class Comida {

    private boolean efecto;
    private String nombre;
    private String figura;
    private int nivelJuego;
    private String descripcion;
    private Comida[] alimentos = new Comida[18];
    private Comida[] comidaTienda = new Comida[2];
    private Tipos nivel = new Tipos("", "", 0, 0, 0, 0, "", 0, 0);

    public Comida(String nombre, String figura, int nivelJuego, boolean efecto, String descripcion) {
        this.nombre = nombre;
        this.nivelJuego = nivelJuego;
        this.efecto = efecto;
        this.figura = figura;
        this.descripcion = descripcion;
    }

    public String getNombre() {
        return nombre;
    }

    public int getNivelJuego() {
        return nivelJuego;
    }

    public boolean Efecto() {
        return efecto;
    }

    public String getFigura() {
        return figura;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public Comida[] getAlimentos() {
        return alimentos;
    }

    public void inicializarAlimentos() {
        //COMIDA NIVEL 1 {NOMBRE-FIGURA-NIVEL-TIPO EFECTO-DESCRIPCION}
        alimentos[0] = new Comida("Manzana", "@", 1, false, "Da +1/+1 a una mascota seleccionada");
        alimentos[1] = new Comida("Naranja", "(+)", 1, true, "Regresa 10% de daño");
        alimentos[2] = new Comida("Miel", "“-”", 1, true, "Invoca a una abeja cuando muere la mascota");

        //COMIDA NIVEL 2 {NOMBRE-FIGURA-NIVEL-TIPO EFECTO-DESCRIPCION}
        alimentos[3] = new Comida("Pastelito", "{^}", 2, false, "Da +3/+3 en una ronda de pelea a una mascota seleccionada");
        alimentos[4] = new Comida("Hueso", "[--]", 2, true, "Da +5 de ataque durante los turnos de pelea");
        alimentos[5] = new Comida("PastillaParaDormir", "¿’?", 2, false, "Desaparece a la mascota");

        //COMIDA NIVEL 3 {NOMBRE-FIGURA-NIVEL-TIPO EFECTO-DESCRIPCION}
        alimentos[6] = new Comida("Ajo", ")+(", 3, true, "Rebice 2 de daño menos la mascota al ser atacada");
        alimentos[7] = new Comida("Ensalada", "{+-*", 3, false, " Da +1/+1 a dos mascotas random");
        alimentos[8] = new Comida("ComidaEnlatada", "[°°]", 3, false, "Da a las mascotas en tienda +2/+1");
        alimentos[9] = new Comida("Pera", "o-’", 3, false, "Da +2/+2 a una mascota seleccionada");

        //COMIDA NIVEL 4 {NOMBRE-FIGURA-NIVEL-TIPO EFECTO-DESCRIPCION}
        alimentos[10] = new Comida("Chile", "--/", 4, true, "Hace +5 de daño a la mascota que se encuentre atras de la mascota atacada");
        alimentos[11] = new Comida("Chocolate", "\\++", 4, false, "Hace que la mascota seleccionada gane +1 de experiencia");
        alimentos[12] = new Comida("Sushi", "/-\\", 4, false, "Da +1/+1 a tres mascotas random");

        //COMIDA NIVEL 5 {NOMBRE-FIGURA-NIVEL-TIPO EFECTO-DESCRIPCION}
        alimentos[13] = new Comida("Melon", "~^~", 5, true, "Hace que la mascota no reciba daño en el primer ataque");
        alimentos[14] = new Comida("Hongo", "~o~", 5, true, "Da una vida extra a la mascota seleccionada");

        //COMIDA NIVEL 6 {NOMBRE-FIGURA-NIVEL-TIPO EFECTO-DESCRIPCION}
        alimentos[15] = new Comida("Pizza", "/z/", 6, false, "Da +2/+2 a dos mascotas random");
        alimentos[16] = new Comida("Carne", "¿-¿", 6, true, "Hace que en cada ronda de pelea dañe +20");

        //COMIDA NIVEL 7 {NOMBRE-FIGURA-NIVEL-TIPO EFECTO-DESCRIPCION}
        alimentos[17] = new Comida("Gelatina", "%¡%", 7, true, "Da un tipo extra a una mascota seleccionada");
    }

    public void mostrarAlimentos() {
        for (int i = 0; i < this.comidaTienda.length; ++i) {
            if (this.comidaTienda[i] != null) {
                System.out.println("\n"+ comidaTienda[i].getNombre() + "-->" + comidaTienda[i].getFigura()
                        + "\nDescripción: " + comidaTienda[i].getDescripcion() + "\n");
            }
        }
    }

    public void mostrarComidaEnTienda(Comida[] alimentos, int Ronda) {
        int comidaAleatoria = 0;

        for (int i = 0; i < comidaTienda.length; ++i) {
            boolean encontro = false;

            while (!encontro) {
                final ThreadLocalRandom tlr = ThreadLocalRandom.current();
                comidaAleatoria = tlr.nextInt(0, 17);
                if (Ronda == 1 || Ronda == 2) {
                    if (alimentos[comidaAleatoria].getNivelJuego() == 1) {
                        encontro = true;
                        this.comidaTienda[i] = alimentos[comidaAleatoria];
                    }

                } else if (Ronda == 3 || Ronda == 4) {
                    if (alimentos[comidaAleatoria].getNivelJuego() <= 2) {
                        encontro = true;
                        this.comidaTienda[i] = alimentos[comidaAleatoria];
                    }

                } else if (Ronda == 5 || Ronda == 6) {
                    if (alimentos[comidaAleatoria].getNivelJuego() <= 3) {
                        encontro = true;
                        this.comidaTienda[i] = alimentos[comidaAleatoria];
                    }

                } else if (Ronda == 7 || Ronda == 8) {
                    if (alimentos[comidaAleatoria].getNivelJuego() <= 4) {
                        encontro = true;
                        this.comidaTienda[i] = alimentos[comidaAleatoria];
                    }

                } else if (Ronda == 9 || Ronda == 10) {
                    if (alimentos[comidaAleatoria].getNivelJuego() <= 5) {
                        encontro = true;
                        this.comidaTienda[i] = alimentos[comidaAleatoria];
                    }

                } else if (Ronda == 11 || Ronda == 12) {
                    if (alimentos[comidaAleatoria].getNivelJuego() <= 6) {
                        encontro = true;
                        this.comidaTienda[i] = alimentos[comidaAleatoria];
                    }

                } else if (Ronda == 13 || Ronda == 14) {
                    if (alimentos[comidaAleatoria].getNivelJuego() <= 7) {
                        encontro = true;
                        this.comidaTienda[i] = alimentos[comidaAleatoria];
                    }

                } else {
                    if (Ronda <= 14 || alimentos[comidaAleatoria].getNivelJuego() > 7) {
                        encontro = true;
                        this.comidaTienda[i] = alimentos[comidaAleatoria];
                    }

                }
            }
        }
    }

    public void comprarComidaEnTienda(Comida[] alimento, int contRonda, Tipos[] miMascota) {
        Scanner entrada = new Scanner(System.in);
        int opcion = 0;
        inicializarAlimentos();
        mostrarComidaEnTienda(getAlimentos(), contRonda);
        while (opcion != -1) {
            System.out.println("-----------------------");
            mostrarAlimentos();
            System.out.println("\t1. Comprar");
            System.out.println("\t-1. Regresar");
            opcion = entrada.nextInt();
            if (opcion == 1) {
                System.out.println("Para comprar la comida ingrese: Nombre de la comida");
                System.out.println("Ejemplo: MANZANA, manzana");
                String comando = entrada.next();
                boolean comprar = false;
                for (int i = 0; i < 2; ++i) {
                    if (alimento[i] != null) {
                        if (MenuBatalla.datos.getOro() < 3) {
                            System.out.println("**No tienes suficiente oro para comprar comida**\n");
                            comprar = true;
                            break;
                        }
                        if (comando.equalsIgnoreCase(comidaTienda[i].getNombre())) {
                            comprar = true;
                            MenuBatalla.datos.setOro(MenuBatalla.datos.getOro() - 3);
                            System.out.println("\t**Comida comprada con  exito**\n");
                            if (comidaTienda[i].getNombre().equalsIgnoreCase("ENSALADA") || comidaTienda[i].getNombre().equalsIgnoreCase("SUSHI") || comidaTienda[i].getNombre().equalsIgnoreCase("PIZZA")) {
                                darComidaAMascotas(comidaTienda[i], miMascota[i], miMascota);
                                for (int j = 0; j < miMascota.length; ++j) {
                                    nivel.mostrarDatos(miMascota[j]);
                                }
                                break;
                            }
                            System.out.println("\t1. Seleccione la mascota");
                            int opcionSeleccion = entrada.nextInt();
                            if (opcionSeleccion == 1) {
                                for (int k = 0; k < miMascota.length; ++k) {
                                    if (miMascota[k] != null) {
                                        nivel.mostrarDatos(miMascota[k]);
                                    }
                                }
                                System.out.println("Ingrese el nombre de la mascota para darle la comida");
                                comando = entrada.next();
                                for (int k = 0; k < miMascota.length; ++k) {
                                    if (miMascota[k] != null && comando.equalsIgnoreCase(miMascota[k].getNombre())) {
                                        darComidaAMascotas(comidaTienda[i], miMascota[k], miMascota);
                                        System.out.println("\n--Comida aplicada con exito--");
                                       nivel.mostrarDatos(miMascota[k]);
                                        comidaTienda[i] = null;
                                        break;
                                    }
                                }
                            }
                            break;
                        }
                    }
                }
                if (comprar == false) {
                    System.out.println("\t**Comando incorrecto**");
                }
                
            }
        }
    }

    public void darComidaAMascotas(Comida alimentos, Tipos mascotas, Tipos[] arreglo) {
        
        if (alimentos.getNombre().equalsIgnoreCase("MANZANA")) {
            mascotas.setPuntosAtaque(mascotas.getPuntosAtaque() + 1);
            mascotas.setPuntosVida(mascotas.getPuntosVida() + 1);
            
        } else if (alimentos.getNombre().equalsIgnoreCase("NARANJA")) {
            mascotas.setEfecto(1);
            
        } else if (alimentos.getNombre().equalsIgnoreCase("MIEL")) {
            mascotas.setEfecto(2);
            
        } else if (alimentos.getNombre().equalsIgnoreCase("PASTELITO")) {
            mascotas.setPuntosAtaque(mascotas.getPuntosAtaque() + 3);
            mascotas.setPuntosVida(mascotas.getPuntosVida() + 3);
            
        } else if (alimentos.getNombre().equalsIgnoreCase("HUESO")) {
            mascotas.setEfecto(3);
            
        } else if (alimentos.getNombre().equalsIgnoreCase("PastillaParaDormir")) {
            mascotas.setEfecto(4);
            
        } else if (alimentos.getNombre().equalsIgnoreCase("AJO")) {
            mascotas.setEfecto(5);
            
        } else if (alimentos.getNombre().equalsIgnoreCase("ENSALADA")) {
            darVida2Random(arreglo);
            
        } else if (alimentos.getNombre().equalsIgnoreCase("COMIDAENLATADA")) {
            for (int i = 0; i < arreglo.length; ++i) {
                arreglo[i].setPuntosAtaque(arreglo[i].getPuntosAtaque() + 2);
                arreglo[i].setPuntosVida(arreglo[i].getPuntosVida() + 1);
            }
            
        } else if (alimentos.getNombre().equalsIgnoreCase("PERA")) {
            mascotas.setPuntosAtaque(mascotas.getPuntosAtaque() + 2);
            mascotas.setPuntosVida(mascotas.getPuntosVida() + 2);
            
        } else if (alimentos.getNombre().equalsIgnoreCase("CHILE")) {
            mascotas.setEfecto(6);
            
        } else if (alimentos.getNombre().equalsIgnoreCase("CHOCALATE")) {
            mascotas.setNivel(mascotas.getNivel() + 1);
            
        } else if (alimentos.getNombre().equalsIgnoreCase("SUSHI")) {
            darVida3Random(arreglo);
            
        } else if (alimentos.getNombre().equalsIgnoreCase("MELON")) {
            mascotas.setEfecto(7);
            
        } else if (alimentos.getNombre().equalsIgnoreCase("HONGO")) {
            mascotas.setEfecto(8);
            
        } else if (alimentos.getNombre().equalsIgnoreCase("PIZZA")) {
            darAtaque2Random(arreglo);
            
        } else if (alimentos.getNombre().equalsIgnoreCase("CARNE")) {
            mascotas.setEfecto(9);
            
        } else if (alimentos.getNombre().equalsIgnoreCase("GELATINA")) {
            mascotas.setEfecto(10);
        }
    }

    public void darVida2Random(Tipos[] mascotas) {
        for (int i = 0; i < 2; ++i) {
            ThreadLocalRandom tlr = ThreadLocalRandom.current();
            int mascotaRandom = tlr.nextInt(0, 4);
            mascotas[mascotaRandom].setPuntosAtaque(mascotas[mascotaRandom].getPuntosAtaque() + 1);
            mascotas[mascotaRandom].setPuntosVida(mascotas[mascotaRandom].getPuntosVida() + 1);
        }
    }

    public void darVida3Random(Tipos[] mascotas) {
        for (int i = 0; i < 3; ++i) {
            ThreadLocalRandom tlr = ThreadLocalRandom.current();
            int mascotaRandom = tlr.nextInt(0, 4);
            mascotas[mascotaRandom].setPuntosAtaque(mascotas[mascotaRandom].getPuntosAtaque() + 1);
            mascotas[mascotaRandom].setPuntosVida(mascotas[mascotaRandom].getPuntosVida() + 1);
        }
    }

    public void darAtaque2Random(Tipos[] mascotas) {
        for (int i = 0; i < 2; ++i) {
            ThreadLocalRandom tlr = ThreadLocalRandom.current();
            int mascotaRandom = tlr.nextInt(0, 4);
            mascotas[mascotaRandom].setPuntosAtaque(mascotas[mascotaRandom].getPuntosAtaque() + 2);
            mascotas[mascotaRandom].setPuntosVida(mascotas[mascotaRandom].getPuntosVida() + 2);
        }
    }
}
