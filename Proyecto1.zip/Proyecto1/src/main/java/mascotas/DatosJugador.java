/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mascotas;

/**
 *
 * @author Kenny
 */
public class DatosJugador {

    private int oro = 10;
    private int vida = 10;
    private int contVictorias = 0;
    private int contRonda = 1;
    private int contDerrotas = 0;

    public int getContRonda() {
        return contRonda;
    }

    public void setContRonda(int contRonda) {
        this.contRonda = contRonda;
    }

    public int getContVictorias() {
        return contVictorias;
    }

    public void setContVictorias(int contVictorias) {
        this.contVictorias = contVictorias;
    }

    public int getContDerrotas() {
        return contDerrotas;
    }

    public void setContDerrotas(int contDerrotas) {
        this.contDerrotas = contDerrotas;
    }

    public int getVida() {
        return vida;
    }

    public void setVida(int vida) {
        this.vida = vida;
    }

    public int getOro() {
        return oro;
    }

    public void setOro(int oro) {
        this.oro = oro;
    }
}
