package mascotas;

/**
 *
 * @author Kenny
 */
public class BufYNerfeo extends Tipos {

    public BufYNerfeo(String nombre, String figura, double puntosAtaque, double puntosVida, int nivel, int nivelJuego, String tipo, int efecto, int fusion) {
        super(nombre, figura, puntosAtaque, puntosVida, nivel, nivelJuego, tipo, efecto, fusion);
    }

    public void bufearMascotaReptil(Tipos[] reptil) { //CAMPO PANTANO
        for (int i = 0; i < reptil.length; ++i) {
            if (reptil[i] != null) {
                try {
                    String[] separador = reptil[i].getTipo().split("/");
                    if (separador[0].equals("reptil") || separador[1].equals("reptil") || reptil[i].getTipo().equalsIgnoreCase("reptil")) {
                        reptil[i].setPuntosAtaque(reptil[i].getPuntosAtaque() + 1);
                        reptil[i].setPuntosVida(reptil[i].getPuntosVida() + 1);
                        mostrarDatos(reptil[i]);
                    }
                } catch (Exception ex) {
                }
            }
        }
    }

    public void bufearMascotaVolador(Tipos[] volador) { // CAMPO NUBES
        for (int i = 0; i < volador.length; ++i) {
            try {
                String[] separador = volador[i].getTipo().split("/");
                if (separador[0].equals("volador") || separador[1].equals("volador") || volador[i].getTipo().equalsIgnoreCase("volador")) {
                    volador[i].setPuntosAtaque(volador[i].getPuntosAtaque() + 1);
                    volador[i].setPuntosVida(volador[i].getPuntosVida() + 1);
                    mostrarDatos(volador[i]);
                }
            } catch (Exception ex) {
            }
        }
    }

    public void bufearMascotaAcuatica(Tipos[] acuatico) { // CAMPO MAR
        for (int i = 0; i < acuatico.length; ++i) {
            try {
                String[] separador = acuatico[i].getTipo().split("/");
                if (separador[0].equals("acuatico") || separador[1].equals("acuatico") || acuatico[i].getTipo().equalsIgnoreCase("acuatico")) {
                    acuatico[i].setPuntosAtaque(acuatico[i].getPuntosAtaque() + 1);
                    acuatico[i].setPuntosVida(acuatico[i].getPuntosVida() + 1);
                    mostrarDatos(acuatico[i]);
                }
            } catch (Exception ex) {
            }
        }
    }

    public void bufearMascotaTerrestreMamiferoSolitario(Tipos[] terrestre) {//CAMPO BOSQUE
        for (int i = 0; i < terrestre.length; ++i) {
            boolean cambio = false;
            try {
                String[] separador = terrestre[i].getTipo().split("/");
                if (separador.length == 3) {
                    if (separador[0].equals("terrestre") || separador[1].equals("terrestre") || separador[2].equals("terrestre")) {
                        terrestre[i].setPuntosAtaque(terrestre[i].getPuntosAtaque() + 2);
                        cambio = true;
                    }
                    if (separador[0].equals("mamifero") || separador[1].equals("mamifero") || separador[2].equals("mamifero")) {
                        terrestre[i].setPuntosVida(terrestre[i].getPuntosVida() + 2);
                        cambio = true;
                    }
                    if (separador[0].equals("solitario") || separador[1].equals("solitario") || separador[2].equals("solitario")) {
                        terrestre[i].setPuntosAtaque(terrestre[i].getPuntosAtaque() - 0.2);
                        cambio = true;
                    }
                } else if (separador.length == 2) {
                    if (separador[0].equals("terrestre") || separador[1].equals("terrestre")) {
                        terrestre[i].setPuntosAtaque(terrestre[i].getPuntosAtaque() + 2);
                        cambio = true;
                    }
                    if (separador[0].equals("mamifero") || separador[1].equals("mamifero")) {
                        terrestre[i].setPuntosVida(terrestre[i].getPuntosVida() + 2);
                        cambio = true;
                    }
                    if (separador[0].equals("solitario") || separador[1].equals("solitario")) {
                        terrestre[i].setPuntosAtaque(terrestre[i].getPuntosAtaque() - 0.2);
                        cambio = true;
                    }
                }
                if (terrestre[i].getTipo().equalsIgnoreCase("terrestre")) {
                    terrestre[i].setPuntosAtaque(terrestre[i].getPuntosAtaque() + 2);
                    cambio = true;
                }
                if (terrestre[i].getTipo().equalsIgnoreCase("mamifero")) {
                    terrestre[i].setPuntosVida(terrestre[i].getPuntosVida() + 2);
                    cambio = true;
                }
                if (terrestre[i].getTipo().equalsIgnoreCase("solitario")) {
                    terrestre[i].setPuntosAtaque(terrestre[i].getPuntosAtaque() - 0.2);
                    cambio = true;
                }

                mostrarDatos(terrestre[i]);

            } catch (Exception ex) {
            }
        }
    }

    public void bufearMascotaDomesticoMamifero(Tipos[] domestico) { // CAMPO GRANJA
        for (int i = 0; i < domestico.length; ++i) {
            boolean cambio = false;
            try {
                String[] separador = domestico[i].getTipo().split("/");
                if (separador.length == 3) {
                    if (separador[0].equals("domestico") || separador[1].equals("domestico") || separador[2].equals("domestico")) {
                        domestico[i].setPuntosAtaque(domestico[i].getPuntosAtaque() + 1);
                        cambio = true;
                    }
                    if (separador[0].equals("mamifero") || separador[1].equals("mamifero") || separador[2].equals("mamifero")) {
                        domestico[i].setPuntosVida(domestico[i].getPuntosVida() + 2);
                        cambio = true;
                    }
                    if (separador[0].equals("solitario") || separador[1].equals("solitario") || separador[2].equals("solitario")) {
                        domestico[i].setPuntosAtaque(domestico[i].getPuntosAtaque() - 0.2);
                        cambio = true;
                    }
                } else if (separador.length == 2) {
                    if (separador[0].equals("domestico") || separador[1].equals("domestico")) {
                        domestico[i].setPuntosAtaque(domestico[i].getPuntosAtaque() + 1);
                        cambio = true;
                    }
                    if (separador[0].equals("mamifero") || separador[1].equals("mamifero")) {
                        domestico[i].setPuntosVida(domestico[i].getPuntosVida() + 2);
                        cambio = true;
                    }
                    if (separador[0].equals("solitario") || separador[1].equals("solitario")) {
                        domestico[i].setPuntosAtaque(domestico[i].getPuntosAtaque() - 0.2);
                        cambio = true;
                    }
                }
                if (domestico[i].getTipo().equalsIgnoreCase("domestico")) {
                    domestico[i].setPuntosAtaque(domestico[i].getPuntosAtaque() + 1);
                    cambio = true;
                }
                if (domestico[i].getTipo().equalsIgnoreCase("mamifero")) {
                    domestico[i].setPuntosVida(domestico[i].getPuntosVida() + 2);
                    cambio = true;
                }
                if (domestico[i].getTipo().equalsIgnoreCase("solitario")) {
                    domestico[i].setPuntosAtaque(domestico[i].getPuntosAtaque() - 0.2);
                    cambio = true;
                }

                mostrarDatos(domestico[i]);

            } catch (Exception ex) {
            }
        }
    }

    public void bufearMascotaSolitaria(Tipos[] solitario) { // SIN CAMPO
        for (int i = 0; i < solitario.length; ++i) {
            try {
                String[] separador = solitario[i].getTipo().split("/");
                if (separador[0].equals("solitario") || separador[1].equals("solitario") || solitario[i].getTipo().equalsIgnoreCase("solitario")) {
                    solitario[i].setPuntosAtaque(solitario[i].getPuntosAtaque() + 3);
                    solitario[i].setPuntosVida(solitario[i].getPuntosVida() + 3);
                    mostrarDatos(solitario[i]);
                }
            } catch (Exception ex) {
            }
        }
    }

    public void bufearMascotaDisertica(Tipos[] disertico) { //SABANA
        for (int i = 0; i < disertico.length; ++i) {
            try {
                final String[] separador = disertico[i].getTipo().split("/");
                if (separador[0].equals("disertico") || separador[1].equals("disertico") || disertico[i].getTipo().equalsIgnoreCase("disertico")) {
                    disertico[i].setPuntosVida(disertico[i].getPuntosVida() + 1);
                    mostrarDatos(disertico[i]);
                }
            } catch (Exception ex) {
            }
        }
    }
}
