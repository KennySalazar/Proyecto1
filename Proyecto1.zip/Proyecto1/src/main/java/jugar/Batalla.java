
package jugar;

/**
 *
 * @author Kenny
 */

import java.util.Scanner;
import desarrolloJuego.MenuBatalla;
import mascotas.Tipos;
import java.lang.Thread;

public class Batalla
{
    private Tipos mascota;
    private Tipos abeja;
    private Tipos[] mazoNuevo;
    
    public Batalla() {
        this.mascota = new Tipos("", "", 0, 0, 0, 0, "", 0, 0);
        this.abeja = new Tipos("Abeja", "°^°", 1, 1, 0, 0, "volador", 0, 0);
        this.mazoNuevo = new Tipos[5];
     
    }
    
    public void iniciarPelea( Tipos[] miMascota,  Tipos[] mascotaRival,  int ronda) {
        int contMiMascota = 0;
        int contMascotaRival = 0;
         Tipos[] miMazoPelea = new Tipos[5];
        boolean fin = false;
        for (int i = 0; i < miMazoPelea.length; ++i) {
            miMazoPelea[i] = miMascota[i];
        }
        while (!fin) {
            if (miMazoPelea[contMiMascota] == null || mascotaRival[contMascotaRival] == null || contMiMascota == miMazoPelea.length - 1 || contMascotaRival == mascotaRival.length - 1) {
                fin = true;
                boolean empate = false;
                boolean gane = true;
                System.out.println("Fin pelea");
                if (miMazoPelea[contMiMascota] == null || contMiMascota == miMazoPelea.length - 1) {
                    gane = false;
                }
                else if (mascotaRival[contMascotaRival] == null || contMascotaRival == mascotaRival.length - 1) {
                    gane = true;
                }
                if ((miMazoPelea[contMiMascota] == null && mascotaRival[contMascotaRival] == null) || (contMiMascota == miMazoPelea.length - 1 && contMascotaRival == mascotaRival.length - 1)) {
                    empate = true;
                }
                if (empate) {
                    System.out.println("¡¡¡HUBO UN EMPATE!!!");
                    MenuBatalla.datos.setOro(10);
                }
                else if (gane) {
                    System.out.println("¡¡¡HAS GANADO!!!");
                    System.out.println("\n--MIS MASCOTAS--");
                    for (int j = 0; j < miMazoPelea.length; ++j) {
                        mascota.mostrarDatos(miMazoPelea[j]);
                    }
                    MenuBatalla.datos.setOro(10);
                    MenuBatalla.datos.setContVictorias(MenuBatalla.datos.getContVictorias() + 1);
                    if (MenuBatalla.datos.getContVictorias() == 10) {
                        System.out.println("HAS GANADO LA PARTIDA!!!");
                    }
                }
                else {
                    System.out.println("¡¡¡HAS PERDIDO!!!");
                    System.out.println("\nGano el equipo Rival");
                    System.out.println("\n---MASCOTAS RIVAL---");
                    for (int j = 0; j < mascotaRival.length; ++j) {
                        mascota.mostrarDatos(mascotaRival[j]);
                    }
                    MenuBatalla.datos.setOro(10);
                    MenuBatalla.datos.setContDerrotas(MenuBatalla.datos.getContDerrotas() + 1);
                    this.restarVida(ronda);
                    if (MenuBatalla.datos.getContDerrotas() == 10) {
                        System.out.println("Has perdido todas tus vidas, por lo tanto.... HAS PERDIDO EL JUEGO");
                        System.exit(0);
                    }
                }
                MenuBatalla.datos.setContRonda(MenuBatalla.datos.getContRonda() + 1);
            }
            else {
                presionarTecla();
                try {
                    for (int i = 0; i < 1; ++i) {
                        System.out.println("\t\tPeleando.......");
                        //Thread.sleep(2000);
                        Thread.sleep(0x7d0);
                        
                        System.out.println("---MI MASCOTA---");
                        miMazoPelea[contMiMascota].mostrarDatos(miMazoPelea[contMiMascota]);
                        System.out.println("VRS\n");
                        System.out.println("---MASCOTA RIVAL--");
                        
                        mascotaRival[contMascotaRival].mostrarDatos(mascotaRival[contMascotaRival]);
                        miMazoPelea[contMiMascota].setPuntosVida(miMazoPelea[contMiMascota].getPuntosVida() - mascotaRival[contMascotaRival].getPuntosAtaque());
                        mascotaRival[contMascotaRival].setPuntosVida(mascotaRival[contMascotaRival].getPuntosVida() - miMazoPelea[contMiMascota].getPuntosAtaque());
                        
                        System.out.println("-------------------------RESULTADO----------------");
                        System.out.println("-----MI MASCOTA----");
                        miMazoPelea[contMiMascota].mostrarDatos(miMazoPelea[contMiMascota]);
                        System.out.println("----MASCOTA RIVAL----");
                        mascotaRival[contMascotaRival].mostrarDatos(mascotaRival[contMascotaRival]);
                        System.out.println("---------------------------------------------------");
                    }
                }
                catch (Exception ex) {}
                
                if (miMazoPelea[contMiMascota].getPuntosVida() <= 0) {
                    if (miMazoPelea[contMiMascota].getEfecto() == 2) {
                        System.out.println("La mascota " + miMazoPelea[contMiMascota].getNombre() + "habia comido miel");
                        System.out.println("Por lo tanto saca a una abeja");
                        miMazoPelea[contMiMascota] = abeja;
                    }
                    else {
                        miMazoPelea[contMiMascota] = null;
                        ++contMiMascota;
                    }
                }
                if (mascotaRival[contMascotaRival].getPuntosVida() > 0.0) {
                    continue;
                }
                if (mascotaRival[contMascotaRival].getEfecto() == 2) {
                    System.out.println("La mascota " + mascotaRival[contMascotaRival].getNombre() + "habia comido miel");
                    System.out.println("Por lo tanto saca a una abeja");
                    mascotaRival[contMascotaRival] = abeja;
                }
                else {
                    mascotaRival[contMascotaRival] = null;
                    ++contMascotaRival;
                }
            }
        }
    }
    
    public void restarVida( int ronda) {
        if (ronda <= 3) {
            MenuBatalla.datos.setVida(MenuBatalla.datos.getVida() - 1);
        }
        else if (ronda > 3 && ronda <= 6) {
            MenuBatalla.datos.setVida(MenuBatalla.datos.getVida() - 2);
        }
        else if (ronda > 7) {
            MenuBatalla.datos.setVida(MenuBatalla.datos.getVida() - 3);
        }
    }
    
    public void presionarTecla() {
        System.out.println("Presione enter o cualquier tecla para -Iniciar La Batalla-");
        final Scanner entrada = new Scanner(System.in);
        entrada.nextLine();
    }
    
    public Tipos[] cambiarMazo( Tipos[] mazoOriginal) {
        this.mazoNuevo = new Tipos[mazoOriginal.length];
        for (int i = 0; i < this.mazoNuevo.length; ++i) {
            this.mazoNuevo[i] = mazoOriginal[i];
        }
        return this.mazoNuevo;
    }
}
